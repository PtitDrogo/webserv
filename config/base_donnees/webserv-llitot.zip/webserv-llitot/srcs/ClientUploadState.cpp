#include "ClientUploadState.hpp"

ClientUploadState::ClientUploadState() : _contentLength(0), _bytesReceived(0), _headersParsed(false), _receivedAll(false) {

}

ClientUploadState::~ClientUploadState() {

}

ClientUploadState::ClientUploadState(const ClientUploadState& other) 
    : _contentLength(other._contentLength),
      _bytesReceived(other._bytesReceived),
      _buffer(other._buffer),
      _headersParsed(other._headersParsed),
      _receivedAll(other._receivedAll),
      _boundary(other._boundary) {}

ClientUploadState& ClientUploadState::operator=(const ClientUploadState& other) {
    if (this != &other) {
        _contentLength = other._contentLength;
        _bytesReceived = other._bytesReceived;
        _buffer = other._buffer;
        _headersParsed = other._headersParsed;
        _receivedAll = other._receivedAll;
        _boundary = other._boundary;
    }
    return *this;
}

void ClientUploadState::setBoundary(const std::string& boundary) {
    _boundary = boundary;
	// std::string key = "boundary=";
	// std::string::size_type pos = buffer.find(key);

	// if (pos != std::string::npos) {
	// 	pos += key.length();
	// 	std::string::size_type end_pos = buffer.find_first_of(" ;\r\n", pos);
	// 	std::string raw_boundary = buffer.substr(pos, end_pos - pos);
	// 	std::string::size_type first_non_dash = raw_boundary.find_first_not_of('-');
	// 	std::string boundary = raw_boundary.substr(first_non_dash);
    //     _boundary = boundary;
	// 	return ;
	// }
	// std::cout << RED << "No boundary find" << RESET << std::endl;
    // _boundary = "";
	// return ; //error
}

std::string ClientUploadState::getBoundary() const {
    return (_boundary);
}

void ClientUploadState::setContentLength(const int length) {
    _contentLength = length;
    // std::string key = "Content-Length: ";
	// size_t pos = buffer.find(key);
	// size_t content_length = 0;

	// if (pos != std::string::npos) {
	// 	std::string length_str = buffer.substr(pos + key.length()); 
	// 	std::istringstream iss(length_str);
	// 	if (iss >> content_length) {
    //         _contentLength = content_length;
	// 		return ;
	// 	}
	// }
	// _contentLength = 0; //0 error
}

int ClientUploadState::getContentLength() const {
    return (_contentLength);
}

std::string ClientUploadState::getBuffer() const {
    return (_buffer);
}

void ClientUploadState::appendToBuffer(const char* chunk, int length) {
    _buffer.append(chunk, length);
}

int ClientUploadState::getBytesReceived() const {
    return (_bytesReceived);
}

void ClientUploadState::setBytesReceived(int bytes) {
    _bytesReceived = bytes;
}

bool ClientUploadState::isReceivedAll() const {
    return (_receivedAll);
}

void ClientUploadState::setReceivedAll(bool received) {
    _receivedAll = received;
}

bool ClientUploadState::areHeadersParsed() const {
    return (_headersParsed);
}

void ClientUploadState::setHeadersParsed(bool parsed) {
    _headersParsed = parsed;
}


// Implémentez les getters et setters