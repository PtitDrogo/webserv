#include "HttpRequestParser.hpp"
#include <iostream>
#include <fstream>
#include <cstdlib>

#include "Webserv.hpp"


HttpRequestParser::HttpRequestParser() {}
HttpRequestParser::~HttpRequestParser() {}

HttpRequestParser::HttpRequestParser(const HttpRequestParser& other) {
	(void)other;
}

HttpRequestParser& HttpRequestParser::operator=(const HttpRequestParser& other) {
	if (this != &other) {
		// Deep copy si nécessaire
	}
	return *this;
}

std::string HttpRequestParser::getRequestType(const std::string& buffer) {
	std::istringstream stream(buffer);
	std::string line;

	while (std::getline(stream, line)) {
		if (line.find("GET") != std::string::npos)
			return "GET";
		if (line.find("POST") != std::string::npos)
			return "POST";
	}
	return "";
}



void HttpRequestParser::parsePostRequest(const std::string& buffer, int client_socket, Server& serv) {
	(void)serv; // Éviter l'avertissement de compilation si non utilisé

	if (buffer.find("Content-Type: multipart/form-data") == std::string::npos) {
		std::cerr << "Error: Content-Type multipart/form-data not found." << std::endl;
		// generate_html_page_error(serv, client_socket, "400");
		return;
	}

	int contentLength = _findContentLength(buffer);
	if (contentLength <= 0) {
		std::cerr << "Error: Invalid Content-Length." << std::endl;
		// generate_html_page_error(serv, client_socket, "400");
		return;
	}

	std::string boundary = _locateBoundary(buffer);
	if (boundary.empty()) {
		std::cerr << "Error: Boundary not found." << std::endl;
		// generate_html_page_error(serv, client_socket, "400");
		return;
	}

	size_t partStart = buffer.find("--" + boundary);
	while (partStart != std::string::npos) {
		size_t partEnd = buffer.find("--" + boundary, partStart + 1);
		if (partEnd == std::string::npos)
			break;

		std::string part = buffer.substr(partStart, partEnd - partStart);
		partStart = partEnd;

		std::string fileName;
		if (!_extractAndValidateFileName(part, fileName)) {
			std::cerr << "Error: Failed to extract or validate filename." << std::endl;
			continue; // Passer à la partie suivante
		}

		std::string contentType, fileContent;
		if (!_extractContentTypeAndData(part, boundary, contentType, fileContent)) {
			std::cerr << "Error: Failed to extract content." << std::endl;
			continue; // Passer à la partie suivante
		}

		std::ofstream outFile(fileName.c_str(), std::ios::binary);
		if (!outFile) {
			std::cerr << "Error: Unable to create file: " << fileName << std::endl;
			continue;
		}
		outFile.write(fileContent.data(), fileContent.size());
		outFile.close();

		std::cout << "File saved successfully: " << fileName << std::endl;
	}

	std::string response = httpHeaderResponse("200 OK", "text/html", "<html><body>File received successfully.</body></html>");
	send(client_socket, response.c_str(), response.size(), 0);
}

int HttpRequestParser::_findContentLength(const std::string& buffer) {
	std::string key = "Content-Length: ";
	size_t pos = buffer.find(key);
	size_t content_length = 0;

	if (pos != std::string::npos) {
		std::string length_str = buffer.substr(pos + key.length());
		std::istringstream iss(length_str);
		if (iss >> content_length) {
			return content_length;
		}
	}
	return 0; // Erreur si la longueur du contenu n'est pas trouvée
}

std::string HttpRequestParser::_locateBoundary(const std::string& buffer) {
	std::string key = "boundary=";
	std::string::size_type pos = buffer.find(key);

	if (pos != std::string::npos) {
		pos += key.length();
		std::string::size_type end_pos = buffer.find_first_of(" ;\r\n", pos);
		std::string raw_boundary = buffer.substr(pos, end_pos - pos);
		std::string::size_type first_non_dash = raw_boundary.find_first_not_of('-');
		std::string boundary = raw_boundary.substr(first_non_dash);
		return boundary;
	}
	std::cout << "No boundary found" << std::endl;
	return ""; // Retourne une chaîne vide en cas d'erreur
}
		
bool HttpRequestParser::_extractAndValidateFileName(const std::string& request, std::string& fileName) {
	const std::string key = "filename=\"";
	size_t fileNamePos = request.find(key);

	if (fileNamePos == std::string::npos) {
		std::cerr << "Error: Filename not found." << std::endl;
		return false;
	}

	size_t endPos = request.find("\"\r\n", fileNamePos);
	if (endPos == std::string::npos) {
		std::cerr << "Error: Invalid filename format." << std::endl;
		return false;
	}

	fileName = request.substr(fileNamePos + key.length(), endPos - (fileNamePos + key.length()));

	// Validation du nom de fichier pour éviter les chemins traversants
	if (fileName.find("/") != std::string::npos || fileName.find("..") != std::string::npos) {
		std::cerr << "Error: Invalid filename." << std::endl;
		return false;
	}

	return true;
}

bool HttpRequestParser::_extractContentTypeAndData(const std::string& request, const std::string& boundary, std::string& contentType, std::string& fileContent) {
	size_t contentTypePos = request.find("Content-Type:", request.find("--" + boundary));
	if (contentTypePos == std::string::npos) {
		std::cerr << "Error: Content-Type not found." << std::endl;
		return false;
	}

	size_t contentTypeEnd = request.find("\r\n", contentTypePos);
	if (contentTypeEnd == std::string::npos) {
		std::cerr << "Error: Malformed Content-Type header." << std::endl;
		return false;
	}
	contentType = request.substr(
		contentTypePos + std::string("Content-Type: ").length(), 
		contentTypeEnd - (contentTypePos + std::string("Content-Type: ").length())
	);

	size_t contentStart = request.find("\r\n\r\n", contentTypeEnd);
	if (contentStart == std::string::npos) {
		std::cerr << "Error: Content start not found." << std::endl;
		return false;
	}
	contentStart += 4;

	// Pour Firefox, on soustrait 30 pour gérer correctement la fin du contenu
	size_t contentEnd = request.find("--" + boundary, contentStart) - 30; 
	if (contentEnd == std::string::npos) {
		std::cerr << "Error: Content end not found." << std::endl;
		return false;
	}
	fileContent = request.substr(contentStart, contentEnd - contentStart);

	return true;
}

void HttpRequestParser::parseGetRequest(const std::string& buffer, Server& serv, int client_socket) {
    std::istringstream stream(buffer);
    std::string line;

    if (!stream) {
        std::cout << "Erreur : le flux n'a pas pu être créé." << std::endl;
        return;
    }

    std::string method;
    std::string path;
    std::string version;
    std::string finalPath;

    while (std::getline(stream, line)) {
        size_t pos1 = line.find("GET");
        size_t pos2 = line.find("HTTP");
		
        if (pos1 != std::string::npos && pos2 != std::string::npos) {
            method = line.substr(pos1, 4);
            path = line.substr(pos1 + 4, pos2 - pos1 - 5);
            version = line.substr(pos2);

            if (path == "/") {
                if (!serv.getIndex().empty())
                    finalPath = "." + serv.getRoot() + serv.getIndex();
                else
                    generate_html_page_error(serv, client_socket, "404");
            } else {
                finalPath = "." + serv.getRoot() + path;
            }
        }
    }

    std::cout << "------------voici le path------------|" << finalPath << "|" << std::endl;
    std::string file_content = readFile(finalPath);
    if (file_content.empty())
        generate_html_page_error(serv, client_socket, "404");

    std::string reponse = httpHeaderResponse("200 Ok", "text/html", file_content);
    send(client_socket, reponse.c_str(), reponse.size(), 0);
}

// Implémentez ici les méthodes statiques parseGetRequest, parsePostRequest, etc.
// Copiez-les depuis votre code précédent de parse_buffer_get et parse_buffer_post
// Ajustez le code pour utiliser les méthodes privées _findContentLength, etc.