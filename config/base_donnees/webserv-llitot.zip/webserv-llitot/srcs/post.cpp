/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   post.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tfreydie <tfreydie@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/11/07 15:57:56 by ilbendib          #+#    #+#             */
/*   Updated: 2024/11/13 13:59:14 by tfreydie         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Post.hpp"

Post::Post()
{
}

Post::~Post()
{
}

Post::Post(const Post &copy)
{
	(void)copy;
}

Post &Post::operator=(const Post &copy)
{
	(void)copy;
	return (*this);
}


