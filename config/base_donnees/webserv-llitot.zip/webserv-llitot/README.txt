Webserver in c++ !
<3 http 1.1
