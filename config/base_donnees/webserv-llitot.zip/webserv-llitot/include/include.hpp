#ifndef INCLUDE_HPP
# define INCLUDE_HPP

//-----------Colours-----------//
#define RESET	"\033[0m"
#define MAGENTA	"\033[35m"
#define YELLOW "\033[33m"
#define BLUE "\033[1;34m"
#define GREEN "\033[32m"
#define RED "\033[31m"
#define NLINE std::cout << std::endl;

//-----------ExternalLibraries-----------//
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <cctype>
#include <sstream>
#include <iterator>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <iostream>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <fstream>
#include <poll.h>


//-----------InternalLibraries-----------//
#include "location.hpp"
#include "print.tpp"
#include "config.hpp"

#endif